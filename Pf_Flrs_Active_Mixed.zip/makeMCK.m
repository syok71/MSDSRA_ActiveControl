function [M,C,K,fn,phin,Mn,Cn,Kn]=makeMCK(m,k,xi)

% Main Structure

M=diag(m);
K=zeros(length(k));
K(1,1)=k(1);
for i=2:length(k)
    temp=k(i)*[1,-1;-1,1];
    K(i-1:i,i-1:i)=K(i-1:i,i-1:i)+temp;
end

[w,f,Eivt]=eigkm(K,M);

w_xi=[w xi];

% C=inv(Eivt')*Eivt'*M*Eivt*diag(2*xi.*w)*inv(Eivt);

coef_Mn = sqrt(sum(diag(M))/sum(diag(Eivt'*M*Eivt)));
Eivt_n = coef_Mn*Eivt;

C=inv(Eivt_n')*Eivt_n'*M*Eivt_n*diag(2*xi.*w)*inv(Eivt_n);

Mn = Eivt_n'*M*Eivt_n;
Cn = Eivt_n'*C*Eivt_n;
Kn = Eivt_n'*K*Eivt_n;
%C2=M*Eivt*diag(2*xi.*w./diag(Mn))*Eivt'*M;

fn=f;
phin=Eivt_n;

