function [A0,B0u,C0y,D0y] = genst_MDOF(m,c,k,xig,wg)
% 1        ~   ndof : story drift
% ndof+1   ~ 2*ndof : absolute acceleration
% 2*ndof+1 ~ 3*ndof : absolute displacement
% 3*ndof+1 ~ 4*ndof : relative velocity between floors
% 4*ndof+1 ~ 5*ndof : absolute velocity

[n,n]=size(m);
O1=zeros(n,n);
O3=zeros(n,1);
I=eye(n,n);
iM=inv(m);
A0=[O1 I zeros(n,1) zeros(n,1);
    -iM*k -iM*c ones(n,1)*wg^2 ones(n,1)*2*wg*xig;
    zeros(n,1)' zeros(n,1)' 0 1;
    zeros(n,1)' zeros(n,1)' -wg^2 -2*wg*xig];


B0u=[O3; zeros(n,1); 0; 1];
C0y=[eye(n),zeros(n,n+2)];
D0y=zeros(n,1);

for j=2:n
   C0y(j,j-1)=-1;
end