function S0 = Szero4PGA(xig,wg,PGA,tau)

Tf = 200;
params.Tf = Tf;
params.tau = tau;
params.PGA = PGA;
params.xig = xig;
params.wg = wg;
x0 = 1;%initial S0

S0 = fminbnd(@(x)FindS0(x,params),0,1);
% options = [];
% [x] = fminunc(@(x)FindS0(x,params),x0,options);

% figure;set(gcf,'color','white');
% plot(std_xgn,S0_value2,'b:',std_xgn,S0_value3,'r-');
% title('\Phi_0 vs. std_{x_g}');
% ylabel('\Phi_0');
% xlabel('std_{x_g}');
% grid on;
% legend('Tf = 1000','wf = 1000');
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end
% 
return

function [to,xt,w] = wn(wa,dt,ts,go)

m_no = ceil(ts/dt);                                                                                                                                                                                                                                                                                                                                                            
wb = 2*pi/dt;
dw = (wb-wa)/m_no;
ts = 2*pi/dw;
to = linspace(0,(m_no-1)*dt,m_no); %to=0:dt:(m_no-1)*dt
w = linspace(0,(m_no-1)*dw,m_no); %w=0:dw:(m_no-1)*dw
v1 = ones(size(w)); %-> This causes aliasing0 effect... doubles the power of white noise.
sigk = sqrt(go*dw*v1);
Ak = raylrnd(sigk);
Ak = [Ak(1:length(Ak)/2) zeros(1,length(Ak)/2)]; % To avoid aliasing.
phi = 2*pi*unifrnd(0,1,1,m_no);
xw = Ak.*exp(i*phi);
%xw = sqrt(2)*sigk.*exp(i*phi); % Spectral Representation
xw = ifft(xw)*m_no;
xt = real(xw);

return

function JJ = FindS0(x,params)

tau = params.tau;
PGA = params.PGA;
xig = params.xig;
wg = params.wg;
Tf = params.Tf;
% Generate whilte noise including frequency and time
dt = 0.01;
wa = 0;
[t,Ft,w] = wn(wa,dt,Tf,1);
t = t';
Ft = Ft';
w = w';% positive for one-sided PSD

% Filter equation
% xig=0.6;%for Prof. Song% 2.98 for Prof. Park
% wg=5*pi;%for Prof. Song% 4.48*2*pi;% for Prof. Park

% Kanai-Tajimi PSD
% PSD=(wg^4+4*xig^2*wg^2*w.^2)./( (wg^2-w.^2).^2 + 4*xig^2*wg^2*w.^2 )*S0;
Sgg = (wg^4+4*xig^2*wg^2*w.^2)./( (wg^2-w.^2).^2 + 4*xig^2*wg^2*w.^2 );

lambda0 = 2*trapz(w,Sgg)*x;
lambda1 = 2*trapz(w,w.*Sgg)*x;
lambda2 = 2*trapz(w,w.^2.*Sgg)*x;
nux0 = 1/pi*sqrt(lambda2/lambda0);
delta = sqrt(1-lambda1^2/(lambda0*lambda2));
if delta <= 0.1
    nue = 2*delta*nux0;
elseif delta > 0.1 && delta <= 0.69
    nue = (1.63*delta^0.45 - 0.38)*nux0;
elseif delta > 0.69 && delta <1
    nue = nux0;
else
    error('Something wrong! delta > 1');
end
if nue*tau >= 2.1
    p = sqrt(2*log(nue*tau)) + 0.5772/sqrt(2*log(nue*tau));
elseif nue*tau < 2.1
    p = 1.253+0.209*nue*tau;
else
    error('Something wrong with ve tau');
end

% Acceleration of ground motion ( Sigma_gg^2 = Hgg*S0 = integral(Sgg,-inf ~ +inf)*S0 )
Hgg = 2*trapz(w,Sgg);   
std_accg = PGA/p;
S0 = (std_accg*9.81).^2/Hgg;  % if Sigma_gg = 0.2g, What is S0 ? 

JJ = abs(S0-x);

return

