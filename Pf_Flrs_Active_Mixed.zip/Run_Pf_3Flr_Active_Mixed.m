clear all;close all;
addpath(['./FERUM/ferumcore']);
addpath(['./FERUM/ferumcore/Distribution and Sensitivities']);
addpath(['./FERUM/ferumcore/Inverse Form']);
addpath(['./FERUM/ferumcore/Sorm CF']);
addpath(['./FERUM/ferumcore/Sorm PF']);
addpath(['./FERUM/ferumcore/Tvedt']);

% global idx_prob S0 idx_crt tau dt idx dh_step
%% Preliminary Definitions
id_flr = 3;
params.id_flr = id_flr;

% System parameters

ndof1=3;
m = 4e5*ones(ndof1,1); % mass : kg
k = 3.17e8*[1;0.9;0.6];
damp_zi = [0.02*ones(ndof1,1)]; % damping ratio : 2%
kc = 1e7;


mu_m = m; 
mu_k = k; 
cov_m = 0.1;
cov_k = 0.1;
cov_zi = 0.1;

[Mmat,Cmat,Kmat,fn,phin,Mn,Cn,Kn]=makeMCK(m,k,damp_zi);


%%
% max_crt = [0.0354, 0.0182]; % maximum criteria for building displacement and damper stroke
x0_rms = 0.03;

tau = 10; % Final time : sec
xig = 0.6; % damping ratio of ground motion
wg = 5*pi; % dominant frequency of ground motion
PGA = 0.3; % Peak Ground Acceleration : g
[S0] = Szero4PGA(xig,wg,PGA,tau); % Find S0 for PGA 0.4g
[std_accg,PGA2] = SzeronPGA(xig,wg,S0,tau); % Find standard deviation(sigma_acc) of ground motion

% Compute beta
% Problem parameters
dt = 0.02; % time step
Tf = tau; % Final time for reliability analysis
tt = [0:dt:Tf]'; % time
Ndsc = length(tt); % Total number of loading data
uu = zeros(Ndsc,1);uu(1) = 1; % Please refer to the paper.

[A0_sim,B0w_sim,C0y_sim,D0y_sim] = genst_MDOF(Mmat,Cmat,Kmat,xig,wg);
B0w_sim=B0w_sim*sqrt(2*pi*S0/dt);
sysun = ss(A0_sim,B0w_sim,C0y_sim,D0y_sim);
params.sysun=sysun;

% w0 = sqrt(k/m);freq0 = w0/2/pi;
% wd = w0*sqrt(1-damp_zi.^2);

% Problem parameters
dt = 0.02;
Tf = tau;
tt = [0:dt:Tf]';
Ndsc = length(tt);
params.Ndsc = Ndsc;

%% FERUM
clear probdata femodel analysisopt gfundata randomfield systems results output_filename
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DATA FIELDS IN 'PROBDATA':                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Marginal distributions for each random variable:


probdata.marg =  [ones(Ndsc,1)*[ 1, 0, 1, 0, zeros(1,5)];
    [ones(3,1), mu_m, mu_m*cov_m, mu_m, zeros(3,5)];
    [ones(3,1), mu_k, mu_k*cov_k, mu_k, zeros(3,5)];
    [ones(3,1), damp_zi, damp_zi*cov_zi, damp_zi, zeros(3,5)]];




% number of criteria
% stability = # of eigen values, response, actuator]

% Correlation matrix (square matrix with dimension equal to number of r.v.'s)
probdata.correlation = eye(Ndsc+3*ndof1);
        
% Determine the parameters,the mean and standard deviation associated
 % with the distribution of each random variable
probdata.parameter = distribution_parameter(probdata.marg);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DATA FIELDS IN 'ANALYSISOPT':                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameters in search algorithm
analysisopt.ig_max = 400;       % Maximum number of global iterations allowed in the search algorithm
analysisopt.il_max = 10;         % Maximum number of line iterations allowed in the search algorithm
analysisopt.e1 = 0.01;         % Tolerance on how close design point is to limit-state surface
analysisopt.e2 = 0.01;         % Tolerance on how accurately the gradient points towards the origin
analysisopt.step_code = 0;      % 0: step size by Armijo rule, otherwise: given value (0 < s <= 1) is the step size.
analysisopt.grad_flag = 'FFD';  % 'DDM': direct differentiation, 'FFD': forward finite difference
        
% Simulation analysis
analysisopt.sim_point = 'dspt'; % 'dspt': design point, 'origin': origin in standard normal space
analysisopt.stdv_sim  = 1;      % Standard deviation of sampling distribution
analysisopt.num_sim   = 100000;   % Number of simulations
analysisopt.target_cov = 0.02;  % Target coefficient of variation of failure probability estimate
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DATA FIELDS IN 'GFUNDATA' (one structure per gfun):  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%----------------------
%Reliability analysis -
%----------------------
% if there is parameters
gfundata(1).parameter = 'no';
gfundata(1).evaluator = 'basic';
gfundata(1).type = 'matlabfile';
%user have to define is limit-state function using the user_lsf.m file and follow the instructions
femodel = 0;
randomfield.mesh = 0;
        
idx_prob = 1;

gfundata(1).thetag = [x0_rms];

% User can define limit-state function parameters
% gfundata(1).thetag = [x0_rms];

ii=1;
idx_crt = ii;
t = clock;
idx_t0 = find(tt==tau);

%%
params.tt = tt;
% params.syst = syst;
params.xig = xig;
params.wg = wg;
params.S0 = S0;
params.dt = dt;
params.kc = kc;
% params.damp_zi=damp_zi;

% p = parpool (6) % CPU Ex) 4 = 4�ھ�
% matlabpool open

gam_n=[3e-15];


simindex=0;
for jj=1:length(gam_n)
    gam = gam_n(jj);
    params.gam=gam;
    
    [A0,B0u,C0y,D0y] = genst(Mmat,Cmat,Kmat);
    sys0 = ss(A0,B0u,C0y,D0y); 
    [Gmat,Smat,Emat] = lqry(sys0,eye(3),gam);
    [At,Bw,Cy,Dy]=genst_MDOF_ctrl(Mmat,Cmat,Kmat,xig,wg,kc,Gmat);
    Bw=Bw*sqrt(2*pi*S0/dt);
    syst = ss(At,Bw,Cy,Dy);
    params.syst = syst;
    
    for kk = idx_t0:-1:2
        idx = kk
        params.idx = idx;
        ijk = kk-1;
        t1 = clock;
        %     probdata.marg(1:Ndsc,4) = dsptx(:,idx-1);
        
        [formresults] = form(1,probdata,analysisopt,gfundata,femodel,randomfield,params);
        time1(1,ijk) = etime(clock,t1);
        
        while isempty(formresults)
            analysisopt.step_code = 0.1;
            [formresults] = form(1,probdata,analysisopt,gfundata,femodel,randomfield,params);
            if isempty(formresults) && simindex <= 8
                analysisopt.step_code = analysisopt.step_code+0.02;
                simindex = simindex+1;
            elseif isempty(formresults) && simindex == 9
                analysisopt.step_code = 0.09;
                simindex = simindex+1;
            elseif isempty(formresults) && simindex <= 18
                analysisopt.step_code = analysisopt.step_code-0.01;
                simindex = simindex+1;
            elseif isempty(formresults) && simindex == 19
                disp('error step size')
            elseif ~isempty(formresults)
                analysisopt.step_code = 0;
            end
        end
        
       
        results(ijk).formresults = formresults;
        pf_n_3rd(1,ijk) = formresults.pf1;
        beta_n_3rd(1,ijk) = formresults.beta1;
        alp_n_3rd(:,ijk) = formresults.alpha;
        time_3rd(1,ijk) = etime(clock,t);
        dsptu_3rd(:,ijk)= formresults.dsptu;
        dsptx_3rd(:,ijk)= formresults.dsptx;
        probdata.marg(:,4) = formresults.dsptx;
%         probdata.marg(:,4) = formresults.beta1*formresults.alpha;
    end
    
%     Ft_n_third = pf_n_third;
%     Beta_n_third = beta_n_third;
%     Alp_n_third = alp_n_third;
%     
%     idx_t1 = idx_t0-1;
%     corr_x = eye(idx_t1);
%     for idx_i=1:idx_t1
%         for idx_j=idx_i+1:idx_t1
%             avec = Alp_n_third(:,idx_i)';
%             bvec = Alp_n_third(:,idx_j);
%             corr_x(idx_i,idx_j) = avec*bvec;
%             corr_x(idx_j,idx_i) = corr_x(idx_i,idx_j);
%         end
%     end
%     
%     % System Approach
%     Num_Smp = 10.^([2,3,4,5,6]);
%     for idxu_i3 = [2,3,4,5,6]-1;
%         idxu_i3;
%         nsmp = 10^(idxu_i3+1);
%         t2 = clock;
%         [p_x2 e] = qsimvnv(nsmp,corr_x,-inf*ones(idx_t1,1),Beta_n_third(1,:)');
%         time2(1,idxu_i3) = etime(clock,t2);
%         
%         PF_XT_third(1,idxu_i3) = 1-p_x2;
%         Beta_XT_third(1,idxu_i3) = -norminv(1-p_x2,0,1);
%     end
    
    
    
    idx_t1 = idx_t0-1;
    Ft_n_3rd = pf_n_3rd(idx:idx_t1);
    Beta_n_3rd = beta_n_3rd(idx:idx_t1);
    Alp_n_3rd = alp_n_3rd(:,idx:idx_t1);
    
    idx_t2 = idx_t0-idx;
    corr_x = eye(idx_t2);
    for idx_i=1:idx_t2
        for idx_j=idx_i+1:idx_t2
            avec = Alp_n_3rd(:,idx_i)';
            bvec = Alp_n_3rd(:,idx_j);
            corr_x(idx_i,idx_j) = avec*bvec;
            corr_x(idx_j,idx_i) = corr_x(idx_i,idx_j);
        end
    end
    % System Approach
    Num_Smp = 10.^([2,3,4,5,6]);
    for idxu_i3 = [2,3,4,5,6]-1;
        idxu_i3;
        nsmp = 10^(idxu_i3+1);
        t2 = clock;
        [p_x2 e] = qsimvnv(nsmp,corr_x,-inf*ones(idx_t2,1),Beta_n_3rd(1,:)');
        time2(1,idxu_i3) = etime(clock,t2);
        
        PF_XT_3rd(1,idxu_i3) = 1-p_x2
        Beta_XT_3rd(1,idxu_i3) = -norminv(1-p_x2,0,1);
        
    end
    
    if jj == 1
        jj
        PF_XT_third
        save Results_MDOF_Active_3rd_gam1
    elseif jj == 2
        jj
        PF_XT_third
        save Results_MDOF_Active_3rd_gam2
    elseif jj == 3
        jj
        PF_XT_third
        save Results_MDOF_Active_3rd_gam3
    elseif jj == 4
        jj
        PF_XT_third
        save Results_MDOF_Active_3rd_gam4
    elseif jj == 5
        jj
        PF_XT_third
        save Results_MDOF_Active_3rd_gam5
    else
        stop;
    end
end





