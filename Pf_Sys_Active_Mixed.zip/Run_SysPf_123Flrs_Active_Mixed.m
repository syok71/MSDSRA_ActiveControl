clear all; close all;

load ..\Sys_joint\Results_MDOF_first_sceond_Mixed_Active_joint.mat
load ..\Sys_joint\Results_MDOF_first_third_Mixed_Active_joint.mat
load ..\Sys_joint\Results_MDOF_second_third_Mixed_Active_joint.mat
load(['..\Sys\Results_MDOF_Active_1st_gam1'],'PF_XT_1st','Beta_XT_1st')
load(['..\Sys\Results_MDOF_Active_2nd_gam1'],'PF_XT_2nd','Beta_XT_2nd')
load(['..\Sys\Results_MDOF_Active_3rd_gam1'],'PF_XT_3rd','Beta_XT_3rd')

% PF_XT_first_third_joint_F=1-(1-PF_XT_first(1,5))-(1-PF_XT_third(1,5))+PF_XT_first_third_joint(1,3);
% pause;
Beta_12 = [Beta_XT_1st(5),Beta_XT_2nd(5)];
Beta_13 = [Beta_XT_1st(5),Beta_XT_3rd(5)];
Beta_23 = [Beta_XT_2nd(5),Beta_XT_3rd(5)];


[rho12] = find_rho(PF_XT_1st_2nd_joint_F,PF_XT_1st(5),PF_XT_2nd(5),Beta_12);
[rho13] = find_rho(PF_XT_1st_3rd_joint_F,PF_XT_1st(5),PF_XT_3rd(5),Beta_13);
[rho23] = find_rho(PF_XT_2nd_3rd_joint_F,PF_XT_2nd(5),PF_XT_3rd(5),Beta_23);


rho = [rho12,rho13,rho23];

Rmat = eye(3);
Rmat(1,2) = rho12*2;
Rmat(1,3) = rho13*2;
Rmat(2,3) = rho23*2;
Rmat = (Rmat+Rmat')/2;

idx=length(Rmat);

nsmp = 1e6;
[p_x2 e] = qsimvnv(nsmp,Rmat,-inf*ones(idx,1),[Beta_XT_1st(5),Beta_XT_2nd(5),Beta_XT_3rd(5)]);

PF_XT_sys = 1-p_x2
Beta_XT_sys = -norminv(1-p_x2,0,1)
% Beta_XT_sys2 = -norminv(p_x2,0,1)


save Results_MDOF_Mixed_Active_Sys
