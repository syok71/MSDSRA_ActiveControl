function int_dP = eval_rho(r,betas)

n_r = length(r);
if n_r == 1
    SigMa = [1,r;r,1];
    int_dP(1) = mvnpdf(betas,[0,0],SigMa);
elseif n_r ~= 1
    for ii=1:n_r
        SigMa = [1,r(ii);r(ii),1];
        int_dP(ii) = mvnpdf(betas,[0,0],SigMa);
    end
end

