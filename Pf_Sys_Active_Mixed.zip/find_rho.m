function [rho] = find_rho(Pf_EiEj,Pf_Ei,Pf_Ej,betas)

dP = Pf_EiEj - Pf_Ei*Pf_Ej;
err = 1;
if dP > 0 % rho: positive
    rho_0 = 0;
    rho_n = 0.9999999999;
    rho_i = 0.5;
    err_old = [];
    while err >= 1e-6
        int_dP = quad(@(r)eval_rho(r,betas),0,rho_i,1e-6);
        err = abs( dP-int_dP );
        rho_x = rho_i;
        if dP > int_dP
            rho_0 = rho_i;
            rho_i = (rho_0+rho_n)/2;
        elseif dP < int_dP
            rho_n = rho_i;
            rho_i = (rho_0+rho_n)/2;
        else
            err = 0;
        end
        err_old = [err_old;err];
        if length(err_old) >= 5
            if std(err_old) < 1e-3
                err = 0;
            end
        end        
    end
elseif dP < 0 % rho: negative
    rho_0 = 0;
    rho_n = -0.9999999999;
    rho_i = -0.5;
    err_old = [];
    while err >= 1e-6
        int_dP = -quad(@(r)eval_rho(r,betas),rho_i,0,1e-6);
        err = abs( dP-int_dP );
        rho_x = rho_i;
        if dP < int_dP
            rho_0 = rho_i;
            rho_i = (rho_0+rho_n)/2;
        elseif dP > int_dP
            rho_n = rho_i;
            rho_i = (rho_0+rho_n)/2;
        else
            err = 0;
        end
        err_old = [err_old;err];
        if length(err_old) >= 5
            if std(err_old) < 1e-3
                err = 0;
            end
        end        
    end
else
    rho_x = 0;
end

rho = rho_x;
