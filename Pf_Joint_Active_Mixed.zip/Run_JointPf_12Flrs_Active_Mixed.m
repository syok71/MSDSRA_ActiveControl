clear all; close all;
% addpath(['./FERUM/ferumcore']);
% addpath(['./FERUM/ferumcore/Distribution and Sensitivities']);
% addpath(['./FERUM/ferumcore/Inverse Form']);
% addpath(['./FERUM/ferumcore/Sorm CF']);
% addpath(['./FERUM/ferumcore/Sorm PF']);
% addpath(['./FERUM/ferumcore/Tvedt']);

load(['..\Sys\Results_MDOF_Active_1st_gam1'],'alp_n_1st','beta_n_1st','PF_XT_1st');


load(['..\Sys\Results_MDOF_Active_2nd_gam1'],'alp_n_2nd','beta_n_2nd','idx_t1','idx_t0','PF_XT_2nd');



alp_n_1st_2nd = [-alp_n_1st(:,5:idx_t1),-alp_n_2nd(:,6:idx_t1)];

Beta_n_1st_2nd = [-beta_n_1st(5:idx_t1),-beta_n_2nd(6:idx_t1)];

idx_t2 = (idx_t0-1)*2-9;
corr_x = eye(idx_t2);

for idx_i=1:idx_t2
    for idx_j=idx_i+1:idx_t2
        avec = alp_n_1st_2nd(:,idx_i)';
        bvec = alp_n_1st_2nd(:,idx_j);
        corr_x(idx_i,idx_j) = avec*bvec;
        corr_x(idx_j,idx_i) = corr_x(idx_i,idx_j);
    end
end


%% System Approach

% PF_XT = 1-mvncdf(beta_x,zeros(1,idx_t1),corr_x)
% PF_UT = 1-mvncdf(beta_u,zeros(1,idx_t1),corr_u)
Num_Smp = 10.^([2,3,4,5,6]);
for idxu_i3 = [2,3,4,5,6]-1;
    idxu_i3
    nsmp = 10^(idxu_i3+1);
    t2 = clock;
    [p_x2 e] = qsimvnv(nsmp,corr_x,-inf*ones(idx_t2,1),-Beta_n_1st_2nd(1,:)');
    time2(1,idxu_i3) = etime(clock,t2);
    PF_XT_1st_2nd_joint(1,idxu_i3) = p_x2
    Beta_XT_1st_2nd_joint(1,idxu_i3) = -norminv(1-p_x2,0,1);
end


PF_XT_1st_2nd_joint_F=1-(1-PF_XT_1st(1,5))-(1-PF_XT_2nd(1,5))+PF_XT_1st_2nd_joint(1,5)


save Results_MDOF_first_sceond_Mixed_Active_joint

